# wintraOS 1.0

Vlastní operační systém postavený na rychlém základu Arch Linux + KDE Plasma, vyladěný pro hry, moderní tmavý vzhled a spouštění aplikací z Windows.

## Co je uvnitř

- **Moderní tmavý vzhled (KDE Plasma)** s vlastním logem, tapetou `wintraOS`, písmem Inter, rozmazáním (blur) a češtinou.
- **Prohlížeč a aplikace:** Microsoft Edge, správce souborů Dolphin, terminál Konsole, obchod s aplikacemi Discover (včetně Flatpaku), `fastfetch`, kalkulačka, textový editor.
- **Hry a výkon:**
  - **Steam** (včetně 32bit knihoven pro Proton)
  - **Prism Launcher** + Java 21 pro **Minecraft** (rychlejší než oficiální launcher, podporuje mody jako Sodium pro výrazně vyšší FPS)
  - **Lutris**, **GameMode**, **MangoHud** (ukazatel FPS), **Gamescope**
  - **Optimalizace systému:** komprimovaná paměť `zram`, nízký `swappiness` a herní `vm.max_map_count`
- **Windows programy (`.exe`):** předinstalované **Wine**, **Winetricks** a **Bottles** (přes Bottles nebo Steam/Proton spustíš většinu Windows aplikací a her).
- **Menší velikost než Windows:** výsledné ISO má okolo 3–4 GB (oproti 25–40 GB po instalaci Windows 11).

> **Na rovinu o macOS aplikacích a FPS:**
> - **macOS aplikace (`.dmg` / `.app`)** na Linuxu spolehlivě neběží (projekt Darling je stále experimentální bez podpory většiny grafických aplikací), takže jsme je nepřidávali, aby systém nebyl rozbitý.
> - **FPS ve hrách:** Minecraft (Java edice + Sodium) a mnoho Vulkan/OpenGL her běží na Linuxu často stejně rychle nebo rychleji než na Windows. U her s kernel anti-cheatem (Valorant, Fortnite apod.) ale Linux bohužel nepodporují.
> - Ve **VirtualBoxu** běží grafika pomaleji než na reálném hardwaru – pro skutečné FPS je potřeba instalace na disk nebo USB.

---

## Jak sestavit vlastní `.iso` soubor (zdarma, bez instalace Linuxu)

Nejjednodušší způsob je **GitHub Actions** – GitHub za tebe ISO sestaví zdarma ve svém cloudu (trvá to asi 15–25 minut):

1. Založ si účet na https://github.com (pokud nemáš) a vytvoř nový repozitář, např. `wintraos`.
2. Nahraj do něj všechny soubory z této složky (`wintraos`).
3. Na GitHubu otevři záložku **Actions** → vlevo klikni na **Sestavit wintraOS ISO** → vpravo klikni na **Run workflow**.
4. Počkej, až sestavení doběhne (zelená fajfka).
5. Klikni na dokončený běh a dole v sekci **Artifacts** stáhni `wintraos-iso` (uvnitř ZIPu je soubor `wintraos-*.iso`).

*(Alternativně, pokud máš na Windows nainstalovaný Docker Desktop nebo WSL2 s Dockerem, stačí ve složce spustit:)*
```bash
docker run --rm --privileged -v "%cd%:/build" archlinux:latest /bin/bash /build/scripts/build-in-container.sh
```

---

## Jak spustit `wintraos.iso` ve VirtualBoxu

1. Stáhni a nainstaluj **VirtualBox** z https://www.virtualbox.org/.
2. Klikni na **Nový (New)**:
   - **Název:** `wintraOS`
   - **ISO obraz:** vyber stažený soubor `wintraos-*.iso`
   - **Typ:** Linux, **Verze:** Arch Linux (64-bit)
3. **Hardware:** nastav alespoň **4096 MB RAM** (ideálně 6–8 GB) a **4 CPU jádra**.
4. **Pevný disk:** můžeš nechat výchozí (pro Live režim není nutný, ale hodí se, kdybys ho chtěl nainstalovat).
5. Po vytvoření otevři **Nastavení → Obrazovka (Display)**:
   - **Videopaměť:** nastav na maximum (**128 MB**)
   - **Grafický řadič:** `VMSVGA`
   - **Povolit 3D akceleraci:** zaškrtni (pokud by obrazovka zčernala, zkus ji vypnout)
6. Klikni na **Spustit (Start)** → v boot menu vyber **wintraOS** a chvíli počkej, než naběhne plocha (přihlásí se samo bez hesla jako uživatel `wintra`).

## Struktura projektu

| Soubor | Popis |
|---|---|
| `.github/workflows/build-iso.yml` | Automatické sestavení ISO na GitHub Actions |
| `scripts/build-in-container.sh` | Hlavní skript pro sestavení ISO přes `archiso` |
| `archiso/packages.extra` | Seznam předinstalovaných aplikací, her a ovladačů |
| `archiso/airootfs/` | Soubory kopírované přímo do wintraOS (vzhled, logo, tapeta, čeština, optimalizace) |
