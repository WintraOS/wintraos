#!/usr/bin/env bash
# =====================================================================
#  wintraOS - sestaveni ISO (bezi uvnitr kontejneru archlinux:latest)
#  Zaklad: oficialni profil "releng" z archiso + upravy wintraOS
# =====================================================================
set -euo pipefail

REPO=/build
WORK=/tmp/wintraos
P="$WORK/profile"

echo "==> Priprava sestavovaciho systemu"
# Kontejner archlinux ma vypnuty multilib (32bit knihovny pro Steam a hry)
cat >> /etc/pacman.conf <<'EOF'

[multilib]
Include = /etc/pacman.d/mirrorlist
EOF
pacman-key --init
pacman-key --populate archlinux
pacman -Syu --noconfirm --needed archiso

echo "==> Pridavam repozitar Chaotic-AUR (Microsoft Edge, Bottles)"
CHAOTIC=1
if pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com \
   && pacman-key --lsign-key 3056513887B78AEB \
   && pacman -U --noconfirm \
        'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst' \
        'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst'; then
    cat >> /etc/pacman.conf <<'EOF'

[chaotic-aur]
Include = /etc/pacman.d/chaotic-mirrorlist
EOF
    pacman -Sy
else
    echo "!! Chaotic-AUR se nepodarilo pridat - Edge a Bottles nebudou predinstalovane"
    CHAOTIC=0
fi

echo "==> Kopiruji zakladni profil releng"
rm -rf "$WORK"
mkdir -p "$WORK"
cp -r /usr/share/archiso/configs/releng "$P"

# Repozitare i pro samotny system wintraOS
cat >> "$P/pacman.conf" <<'EOF'

[multilib]
Include = /etc/pacman.d/mirrorlist
EOF
if [ "$CHAOTIC" = 1 ]; then
    cat >> "$P/pacman.conf" <<'EOF'

[chaotic-aur]
Include = /etc/pacman.d/chaotic-mirrorlist
EOF
fi

echo "==> Odstranuji veci z releng, ktere wintraOS nahrazuje"
# automaticke prihlaseni roota do textove konzole -> nahradi graficke prihlaseni
rm -f "$P/airootfs/etc/systemd/system/getty@tty1.service.d/autologin.conf"
# sit pres systemd-networkd/iwd -> nahradi NetworkManager (ikonka site v liste)
find "$P/airootfs/etc/systemd/system" \( -name 'systemd-networkd*' -o -name 'iwd.service' \) -delete || true
rm -rf "$P/airootfs/etc/systemd/network"

echo "==> Pridavam soubory wintraOS"
cp -a "$REPO/archiso/airootfs/." "$P/airootfs/"

echo "==> Sestavuji seznam balicku"
grep -v -x -e 'virtualbox-guest-utils-nox' "$P/packages.x86_64" > "$WORK/packages"
while read -r pkg; do
    pkg="${pkg%%#*}"; pkg="$(echo "$pkg" | xargs)"
    [ -z "$pkg" ] && continue
    if pacman -Si "$pkg" >/dev/null 2>&1; then
        echo "$pkg" >> "$WORK/packages"
    else
        echo "!! Balicek '$pkg' neni dostupny, preskakuji"
    fi
done < "$REPO/archiso/packages.extra"
sort -u "$WORK/packages" > "$P/packages.x86_64"

echo "==> Upravuji nazev a boot menu"
sed -i \
    -e 's/^iso_name=.*/iso_name="wintraos"/' \
    -e 's/^iso_label=.*/iso_label="WINTRAOS_$(date +%Y%m)"/' \
    -e 's/^iso_publisher=.*/iso_publisher="wintraOS"/' \
    -e 's/^iso_application=.*/iso_application="wintraOS Live"/' \
    -e 's|^file_permissions=(|file_permissions=(\n  ["/etc/sudoers.d/wintraos"]="0:0:440"\n  ["/usr/local/bin/wintraos-setup"]="0:0:755"\n  ["/usr/local/bin/wintraos-firstrun"]="0:0:755"|' \
    "$P/profiledef.sh"
grep -rl 'Arch Linux' "$P/syslinux" "$P/efiboot" "$P/grub" 2>/dev/null | xargs -r sed -i 's/Arch Linux/wintraOS/g'

echo "==> Sestavuji ISO (trva to dlouho)"
mkdir -p "$REPO/out"
mkarchiso -v -w "$WORK/work" -o "$REPO/out" "$P"

ls -lh "$REPO/out"
echo "==> Hotovo!"
