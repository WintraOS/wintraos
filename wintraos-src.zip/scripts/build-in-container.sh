#!/usr/bin/env bash
# =====================================================================
#  wintraOS 2.0 - sestaveni ISO (bezi uvnitr kontejneru archlinux:latest)
# =====================================================================
set -euo pipefail

REPO=/build
WORK=/tmp/wintraos
P="$WORK/profile"

echo "==> Priprava sestavovaciho systemu"
cat >> /etc/pacman.conf <<'EOF'

[multilib]
Include = /etc/pacman.d/mirrorlist
EOF
pacman-key --init
pacman-key --populate archlinux
pacman -Syu --noconfirm --needed archiso

echo "==> Pridavam repozitar Chaotic-AUR (Microsoft Edge, Bottles)"
CHAOTIC=1
if pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com \
   && pacman-key --lsign-key 3056513887B78AEB \
   && pacman -U --noconfirm \
        'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst' \
        'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst'; then
    cat >> /etc/pacman.conf <<'EOF'

[chaotic-aur]
Include = /etc/pacman.d/chaotic-mirrorlist
EOF
    pacman -Sy
else
    echo "!! Chaotic-AUR se nepodarilo pridat - Edge a Bottles nebudou predinstalovane"
    CHAOTIC=0
fi

echo "==> Kopiruji zakladni profil releng"
rm -rf "$WORK"
mkdir -p "$WORK"
cp -r /usr/share/archiso/configs/releng "$P"

cat >> "$P/pacman.conf" <<'EOF'

[multilib]
Include = /etc/pacman.d/mirrorlist
EOF
if [ "$CHAOTIC" = 1 ]; then
    cat >> "$P/pacman.conf" <<'EOF'

[chaotic-aur]
Include = /etc/pacman.d/chaotic-mirrorlist
EOF
fi

echo "==> Odstranuji veci z releng, ktere wintraOS nahrazuje"
rm -f "$P/airootfs/etc/systemd/system/getty@tty1.service.d/autologin.conf"
find "$P/airootfs/etc/systemd/system" \( -name 'systemd-networkd*' -o -name 'iwd.service' \) -delete || true
rm -rf "$P/airootfs/etc/systemd/network"

echo "==> Pridavam soubory wintraOS 2.0"
cp -a "$REPO/archiso/airootfs/." "$P/airootfs/"

echo "==> Vlastni boot menu wintraOS 2.0 (graficky splash + 6 GB mista v Live rezimu)"
cp -f "$REPO/archiso/splash.png" "$P/syslinux/splash.png"

cat > "$P/syslinux/archiso_head.cfg" <<'EOF'
SERIAL 0 115200
UI vesamenu.c32
MENU TITLE
MENU BACKGROUND splash.png

MENU WIDTH 72
MENU MARGIN 6
MENU ROWS 6
MENU VSHIFT 8
MENU TABMSGROW 18
MENU CMDLINEROW 18
MENU HELPMSGROW 20
MENU HELPMSGENDROW 23

MENU COLOR border       30;44   #00000000 #00000000 none
MENU COLOR title        1;36;44 #ff5b9bff #00000000 none
MENU COLOR sel          7;37;40 #ffffffff #aa2b5ce6 none
MENU COLOR unsel        37;44   #ffd8e4ff #00000000 none
MENU COLOR help         37;40   #ffa8c0e0 #00000000 none
MENU COLOR timeout_msg  37;40   #ffa8c0e0 #00000000 none
MENU COLOR timeout      1;37;40 #ff5b9bff #00000000 none
MENU COLOR msg07        37;40   #90ffffff #00000000 std
MENU COLOR tabmsg       31;40   #80a8c0e0 #00000000 none

MENU CLEAR
MENU IMMEDIATE
EOF

cat > "$P/syslinux/archiso_sys-linux.cfg" <<'EOF'
LABEL wintraos
TEXT HELP
Start wintraOS 3.0 (6 GB workspace, Windows 11 apps, gaming & studio).
ENDTEXT
MENU LABEL  >  Start wintraOS 3.0
LINUX /%INSTALL_DIR%/boot/%ARCH%/vmlinuz-linux
INITRD /%INSTALL_DIR%/boot/%ARCH%/initramfs-linux.img
APPEND archisobasedir=%INSTALL_DIR% archisosearchuuid=%ARCHISO_UUID% cow_spacesize=6G quiet loglevel=3 systemd.show_status=auto

LABEL wintraos-safe
TEXT HELP
Start wintraOS 3.0 in Safe Graphics mode.
ENDTEXT
MENU LABEL  >  wintraOS 3.0 (Safe Graphics)
LINUX /%INSTALL_DIR%/boot/%ARCH%/vmlinuz-linux
INITRD /%INSTALL_DIR%/boot/%ARCH%/initramfs-linux.img
APPEND archisobasedir=%INSTALL_DIR% archisosearchuuid=%ARCHISO_UUID% cow_spacesize=6G nomodeset quiet loglevel=3
EOF

cat > "$P/syslinux/archiso_tail.cfg" <<'EOF'
LABEL reboot
MENU LABEL  >  Reboot
COM32 reboot.c32

LABEL poweroff
MENU LABEL  >  Power Off
COM32 poweroff.c32
EOF

cat > "$P/syslinux/archiso_sys.cfg" <<'EOF'
INCLUDE archiso_head.cfg

DEFAULT wintraos
TIMEOUT 40

INCLUDE archiso_sys-linux.cfg
INCLUDE archiso_tail.cfg
EOF

# I pro UEFI boot (systemd-boot / GRUB) pridame cow_spacesize=6G quiet a nazev wintraOS 2.0
grep -rl 'Arch Linux' "$P/efiboot" "$P/grub" 2>/dev/null | xargs -r sed -i 's/Arch Linux/wintraOS 2.0/g'
find "$P/efiboot" "$P/grub" -type f -name '*.cfg' -o -name '*.conf' 2>/dev/null | xargs -r sed -i 's/archisosearchuuid=%ARCHISO_UUID%/archisosearchuuid=%ARCHISO_UUID% cow_spacesize=6G quiet loglevel=3/g'

echo "==> Sestavuji seznam balicku"
grep -v -x -e 'virtualbox-guest-utils-nox' "$P/packages.x86_64" > "$WORK/packages"
while read -r pkg; do
    pkg="${pkg%%#*}"; pkg="$(echo "$pkg" | xargs)"
    [ -z "$pkg" ] && continue
    if pacman -Si "$pkg" >/dev/null 2>&1; then
        echo "$pkg" >> "$WORK/packages"
    else
        echo "!! Balicek '$pkg' neni dostupny, preskakuji"
    fi
done < "$REPO/archiso/packages.extra"
sort -u "$WORK/packages" > "$P/packages.x86_64"

echo "==> Upravuji profiledef.sh (nazev, prava, rychla zstd komprese)"
sed -i \
    -e 's/^iso_name=.*/iso_name="wintraos"/' \
    -e 's/^iso_label=.*/iso_label="WINTRAOS_30"/' \
    -e 's/^iso_publisher=.*/iso_publisher="wintraOS"/' \
    -e 's/^iso_application=.*/iso_application="wintraOS 3.0"/' \
    -e "s|^airootfs_image_tool_options=.*|airootfs_image_tool_options=('-comp' 'zstd' '-Xcompression-level' '6' '-b' '1M')|" \
    -e 's|^file_permissions=(|file_permissions=(\n  ["/etc/sudoers.d/wintraos"]="0:0:440"\n  ["/usr/local/bin/wintraos-setup"]="0:0:755"\n  ["/usr/local/bin/wintraos-firstrun"]="0:0:755"\n  ["/usr/local/bin/wintraos-run-exe"]="0:0:755"|' \
    "$P/profiledef.sh"

echo "==> Uvolnuji cache a sestavuji wintraOS 3.0 ISO"
pacman -Scc --noconfirm || true
mkdir -p "$REPO/out"
mkarchiso -v -w "$WORK/work" -o "$REPO/out" "$P"

ls -lh "$REPO/out"
echo "==> Hotovo!"
