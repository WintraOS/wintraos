import QtQuick 2.15

Rectangle {
    id: root
    color: "#070b14"

    property int stage

    Column {
        anchors.centerIn: parent
        spacing: 22

        Image {
            source: "file:///usr/share/wintraos/logo.png"
            width: 112
            height: 112
            fillMode: Image.PreserveAspectFit
            anchors.horizontalCenter: parent.horizontalCenter
            smooth: true
        }

        Text {
            text: "wintraOS 3.1"
            color: "#ffffff"
            font.family: "Inter"
            font.pixelSize: 32
            font.bold: true
            anchors.horizontalCenter: parent.horizontalCenter
        }

        Rectangle {
            width: 220
            height: 6
            radius: 3
            color: "#1e293b"
            anchors.horizontalCenter: parent.horizontalCenter

            Rectangle {
                height: parent.height
                radius: 3
                color: "#3b82f6"
                width: Math.min(parent.width, (stage / 6.0) * parent.width + 36)
                Behavior on width { NumberAnimation { duration: 250 } }
            }
        }
    }
}
