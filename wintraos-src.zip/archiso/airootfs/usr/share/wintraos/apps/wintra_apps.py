#!/usr/bin/env python3
"""
wintraOS 3.0 - Native PyQt6 Application Suite (English US primary + live Language Switcher)
Usage: wintra_apps.py [--setup | --calc | --games | --clock | --paint | --weather | --security | --vpn | --calendar | --screenshot]
"""
import sys, os, json, random, subprocess
from datetime import datetime
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QPixmap, QImage, QFont, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QLineEdit, QStackedWidget, QTabWidget, QTextEdit,
    QCalendarWidget, QFileDialog, QColorDialog, QSlider, QProgressBar,
    QComboBox, QMessageBox, QFrame
)

LOGO_PATH = "/usr/share/wintraos/logo.png"
PROFILE_PATH = os.path.expanduser("~/.wintraos_profile.json")

LANGUAGES = [
    ("English (United States)", "en_US.UTF-8", "us", "en"),
    ("Čeština (Česko)",         "cs_CZ.UTF-8", "cz", "cs"),
    ("Deutsch (Deutschland)",   "de_DE.UTF-8", "de", "en"),
    ("Español (España)",        "es_ES.UTF-8", "es", "en"),
    ("Français (France)",       "fr_FR.UTF-8", "fr", "en"),
    ("Slovenčina (Slovensko)",  "sk_SK.UTF-8", "sk", "cs"),
]

STRINGS = {
    "en": {
        "welcome": "Welcome to wintraOS 3.0",
        "sub": "A next-generation Full HD desktop with 13 native Wintra apps,\nMicrosoft Edge, Chrome, Steam, Spotify, Blender, ChatGPT & Windows 11 .exe support.",
        "choose_lang": "System Language:",
        "start_setup": "Start Setup  →",
        "profile_hdr": "Your Profile & Apps",
        "your_name": "What should wintraOS call you?",
        "preinstalled": "Pre-installed & ready to launch:",
        "p_web": "• Web & AI: Microsoft Edge, Google Chrome, ChatGPT, Spotify",
        "p_game": "• Gaming & 3D: Steam, Prism Launcher (Minecraft), Blender, GameMode",
        "p_win": "• Windows 11 (.exe / .msi): Double-click Wintra Runner + Bottles",
        "p_store": "• Install any app: App Store (Discover + Flathub)",
        "back": "← Back", "next": "Next  →",
        "ready_hdr": "You're all set!",
        "r1": "✓  Your custom wallpaper in crisp Full HD",
        "r2": "✓  13 native Wintra apps ready in the dock & app grid",
        "r3": "✓  Wintra Security & WintraVPN ready",
        "r4": "✓  6 GB live workspace enabled automatically",
        "launch": "Launch wintraOS 3.0 🚀",
        "calc_title": "Wintra Calculator", "games_title": "Wintra Games",
        "clock_title": "Wintra Clock", "paint_title": "Wintra Paint",
        "weather_title": "Wintra Weather", "sec_title": "Wintra Security",
        "vpn_title": "WintraVPN", "cal_title": "Wintra Calendar",
        "snap_title": "Wintra Screenshot",
    },
    "cs": {
        "welcome": "Vítej ve wintraOS 3.0",
        "sub": "Moderní Full HD systém s 13 vlastními aplikacemi wintraOS,\nMicrosoft Edge, Chrome, Steamem, Spotify, Blenderem, ChatGPT a Windows 11 .exe.",
        "choose_lang": "Jazyk systému:",
        "start_setup": "Začít nastavení  →",
        "profile_hdr": "Tvůj profil a aplikace",
        "your_name": "Jak ti má wintraOS říkat?",
        "preinstalled": "Předinstalované aplikace připravené k použití:",
        "p_web": "• Web a AI: Microsoft Edge, Google Chrome, ChatGPT, Spotify",
        "p_game": "• Hry a 3D: Steam, Prism Launcher (Minecraft), Blender, GameMode",
        "p_win": "• Windows 11 (.exe / .msi): dvojklik přes Wintra Runner + Bottles",
        "p_store": "• Instalace dalších aplikací: Obchod (Discover + Flathub)",
        "back": "← Zpět", "next": "Další  →",
        "ready_hdr": "Vše je připraveno!",
        "r1": "✓  Tvoje tapeta nastavena v ostrém Full HD",
        "r2": "✓  13 vlastních aplikací wintraOS připraveno v docku a menu",
        "r3": "✓  Wintra Zabezpečení a WintraVPN aktivní",
        "r4": "✓  6 GB volného prostoru v Live režimu automaticky",
        "launch": "Spustit wintraOS 3.0 🚀",
        "calc_title": "Wintra Kalkulačka", "games_title": "Wintra Hry",
        "clock_title": "Wintra Hodiny", "paint_title": "Wintra Malování",
        "weather_title": "Wintra Počasí", "sec_title": "Wintra Zabezpečení",
        "vpn_title": "WintraVPN", "cal_title": "Wintra Kalendář",
        "snap_title": "Wintra Screenshot",
    }
}

def get_lang():
    try:
        if os.path.exists(PROFILE_PATH):
            return json.load(open(PROFILE_PATH)).get("ui_lang", "en")
    except Exception:
        pass
    return "en"

def tr(key, lang=None):
    l = lang or get_lang()
    return STRINGS.get(l, STRINGS["en"]).get(key, STRINGS["en"].get(key, key))

QSS = """
QMainWindow, QWidget {
    background-color: #0b1120;
    color: #f1f5f9;
    font-family: 'Inter', 'Noto Sans', sans-serif;
    font-size: 13px;
}
QFrame#Card {
    background-color: #131c31;
    border: 1px solid #24324d;
    border-radius: 14px;
}
QPushButton {
    background-color: #1e293b;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 9px;
    padding: 8px 14px;
    font-weight: 600;
}
QPushButton:hover { background-color: #2d3d56; border-color: #5b9bff; }
QPushButton:pressed { background-color: #172033; }
QPushButton#Primary { background-color: #3b82f6; border: none; color: #ffffff; }
QPushButton#Primary:hover { background-color: #2563eb; }
QPushButton#Success { background-color: #10b981; border: none; color: #ffffff; }
QPushButton#Success:hover { background-color: #059669; }
QPushButton#Danger { background-color: #ef4444; border: none; color: #ffffff; }
QLineEdit, QTextEdit, QComboBox {
    background-color: #080d18;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 9px;
    padding: 8px 10px;
}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus { border-color: #5b9bff; }
QTabWidget::pane { border: 1px solid #24324d; border-radius: 10px; background: #111827; }
QTabBar::tab {
    background: #1e293b; color: #cbd5e1; padding: 8px 16px;
    border-top-left-radius: 8px; border-top-right-radius: 8px; margin-right: 4px;
}
QTabBar::tab:selected { background: #3b82f6; color: #ffffff; font-weight: 700; }
QProgressBar { background: #1e293b; border-radius: 6px; text-align: center; color: #fff; height: 14px; }
QProgressBar::chunk { background: #3b82f6; border-radius: 6px; }
"""

def set_app_icon(win):
    if os.path.exists(LOGO_PATH):
        win.setWindowIcon(QIcon(LOGO_PATH))

# =====================================================================
#  1. WINTRAOS 3.0 SETUP WIZARD (with Live Language Selector!)
# =====================================================================
class SetupWizard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("wintraOS 3.0 — Setup")
        self.setFixedSize(650, 500)
        set_app_icon(self)
        self.ui_lang = "en"
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        # Page 1: Welcome + Language Selector
        p1 = QWidget()
        l1 = QVBoxLayout(p1); l1.setContentsMargins(40, 28, 40, 28); l1.setSpacing(12)
        l1.addStretch()
        logo = QLabel(); logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if os.path.exists(LOGO_PATH):
            logo.setPixmap(QPixmap(LOGO_PATH).scaled(82, 82, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        l1.addWidget(logo)
        self.t1 = QLabel(); self.t1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.t1.setStyleSheet("font-size: 28px; font-weight: 800; color: #ffffff;")
        l1.addWidget(self.t1)
        self.s1 = QLabel(); self.s1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.s1.setStyleSheet("color: #94a3b8; font-size: 13px;")
        l1.addWidget(self.s1)

        lang_row = QHBoxLayout()
        self.lbl_lang = QLabel()
        self.lang_box = QComboBox()
        for label, _, _, _ in LANGUAGES:
            self.lang_box.addItem(label)
        self.lang_box.setCurrentIndex(0)  # English (United States) default!
        self.lang_box.currentIndexChanged.connect(self.on_lang_changed)
        lang_row.addStretch(); lang_row.addWidget(self.lbl_lang); lang_row.addWidget(self.lang_box); lang_row.addStretch()
        l1.addLayout(lang_row)

        l1.addStretch()
        self.b1 = QPushButton(); self.b1.setObjectName("Primary"); self.b1.setMinimumHeight(44)
        self.b1.clicked.connect(lambda: self.stack.setCurrentIndex(1))
        l1.addWidget(self.b1)
        self.stack.addWidget(p1)

        # Page 2: Profile & Apps
        p2 = QWidget()
        l2 = QVBoxLayout(p2); l2.setContentsMargins(40, 30, 40, 30); l2.setSpacing(12)
        self.h2 = QLabel(); self.h2.setStyleSheet("font-size: 22px; font-weight: 700;"); l2.addWidget(self.h2)
        self.lbl_name = QLabel(); l2.addWidget(self.lbl_name)
        self.name_in = QLineEdit("Mathi"); l2.addWidget(self.name_in)
        self.lbl_pre = QLabel(); l2.addWidget(self.lbl_pre)
        card = QFrame(); card.setObjectName("Card"); cl = QVBoxLayout(card)
        self.p_web = QLabel(); self.p_game = QLabel(); self.p_win = QLabel(); self.p_store = QLabel()
        for lbl in (self.p_web, self.p_game, self.p_win, self.p_store): cl.addWidget(lbl)
        l2.addWidget(card); l2.addStretch()
        nav2 = QHBoxLayout()
        self.bb2 = QPushButton(); self.bb2.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        self.bn2 = QPushButton(); self.bn2.setObjectName("Primary"); self.bn2.clicked.connect(lambda: self.stack.setCurrentIndex(2))
        nav2.addWidget(self.bb2); nav2.addStretch(); nav2.addWidget(self.bn2)
        l2.addLayout(nav2)
        self.stack.addWidget(p2)

        # Page 3: Ready
        p3 = QWidget()
        l3 = QVBoxLayout(p3); l3.setContentsMargins(40, 30, 40, 30); l3.setSpacing(14)
        self.h3 = QLabel(); self.h3.setStyleSheet("font-size: 24px; font-weight: 800; color: #34d399;"); l3.addWidget(self.h3)
        c3 = QFrame(); c3.setObjectName("Card"); c3l = QVBoxLayout(c3)
        self.r1 = QLabel(); self.r2 = QLabel(); self.r3 = QLabel(); self.r4 = QLabel()
        for lbl in (self.r1, self.r2, self.r3, self.r4): c3l.addWidget(lbl)
        l3.addWidget(c3); l3.addStretch()
        nav3 = QHBoxLayout()
        self.bb3 = QPushButton(); self.bb3.clicked.connect(lambda: self.stack.setCurrentIndex(1))
        self.bf = QPushButton(); self.bf.setObjectName("Success"); self.bf.setMinimumHeight(46)
        self.bf.clicked.connect(self.finish)
        nav3.addWidget(self.bb3); nav3.addStretch(); nav3.addWidget(self.bf)
        l3.addLayout(nav3)
        self.stack.addWidget(p3)

        self.apply_texts()

    def on_lang_changed(self, idx):
        self.ui_lang = LANGUAGES[idx][3]
        self.apply_texts()

    def apply_texts(self):
        l = self.ui_lang
        self.t1.setText(tr("welcome", l)); self.s1.setText(tr("sub", l))
        self.lbl_lang.setText(tr("choose_lang", l)); self.b1.setText(tr("start_setup", l))
        self.h2.setText(tr("profile_hdr", l)); self.lbl_name.setText(tr("your_name", l))
        self.lbl_pre.setText(tr("preinstalled", l))
        self.p_web.setText(tr("p_web", l)); self.p_game.setText(tr("p_game", l))
        self.p_win.setText(tr("p_win", l)); self.p_store.setText(tr("p_store", l))
        self.bb2.setText(tr("back", l)); self.bn2.setText(tr("next", l))
        self.h3.setText(tr("ready_hdr", l))
        self.r1.setText(tr("r1", l)); self.r2.setText(tr("r2", l))
        self.r3.setText(tr("r3", l)); self.r4.setText(tr("r4", l))
        self.bb3.setText(tr("back", l)); self.bf.setText(tr("launch", l))

    def finish(self):
        idx = self.lang_box.currentIndex()
        label, locale_code, kb_layout, ui_lang = LANGUAGES[idx]
        with open(PROFILE_PATH, "w", encoding="utf-8") as f:
            json.dump({"name": self.name_in.text().strip() or "Mathi", "locale": locale_code, "ui_lang": ui_lang, "setup_done": True}, f)

        # Apply KDE Plasma locale & keyboard layout
        cfg_dir = os.path.expanduser("~/.config")
        os.makedirs(cfg_dir, exist_ok=True)
        short_lang = locale_code.split(".")[0]
        with open(os.path.join(cfg_dir, "plasma-localerc"), "w", encoding="utf-8") as f:
            f.write(f"[Formats]\nLANG={locale_code}\n\n[Translations]\nLANGUAGE={short_lang}\n")
        layouts = f"{kb_layout},us" if kb_layout != "us" else "us,cz"
        with open(os.path.join(cfg_dir, "kxkbrc"), "w", encoding="utf-8") as f:
            f.write(f"[Layout]\nDisplayNames=,\nLayoutList={layouts}\nOptions=grp:alt_shift_toggle\nResetOldOptions=true\nUse=true\nVariantList=,\n")
        subprocess.run(["sudo", "localectl", "set-locale", f"LANG={locale_code}"], capture_output=True)
        self.close()

# =====================================================================
#  2. WINTRA CALCULATOR
# =====================================================================
class CalcApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("calc_title"))
        self.setFixedSize(330, 440); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w)
        lay = QVBoxLayout(w); lay.setContentsMargins(16, 16, 16, 16); lay.setSpacing(10)
        self.hist = QLabel(""); self.hist.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.hist.setStyleSheet("color: #94a3b8; font-size: 13px;"); lay.addWidget(self.hist)
        self.disp = QLineEdit("0"); self.disp.setAlignment(Qt.AlignmentFlag.AlignRight); self.disp.setReadOnly(True)
        self.disp.setStyleSheet("font-size: 30px; font-weight: 700; padding: 14px; background: #070b14;")
        lay.addWidget(self.disp)
        grid = QGridLayout(); grid.setSpacing(8)
        rows = [["C","(",")","/"],["7","8","9","*"],["4","5","6","-"],["1","2","3","+"],["0",".","⌫","="]]
        for r, row in enumerate(rows):
            for c, txt in enumerate(row):
                b = QPushButton(txt); b.setMinimumHeight(52); b.setStyleSheet("font-size: 17px;")
                if txt in "/*-+": b.setObjectName("Primary")
                elif txt == "=": b.setObjectName("Success")
                elif txt == "C": b.setObjectName("Danger")
                b.clicked.connect(lambda _, t=txt: self.press(t))
                grid.addWidget(b, r, c)
        lay.addLayout(grid); self.expr = ""

    def press(self, t):
        if t == "C": self.expr = ""; self.disp.setText("0"); self.hist.setText("")
        elif t == "⌫": self.expr = self.expr[:-1]; self.disp.setText(self.expr or "0")
        elif t == "=":
            try:
                if not all(ch in "0123456789.+-*/() " for ch in self.expr): raise ValueError
                res = eval(self.expr, {"__builtins__": None}, {})
                self.hist.setText(self.expr + " =")
                s = str(int(res) if isinstance(res, float) and res.is_integer() else round(res, 8))
                self.expr = s; self.disp.setText(s)
            except Exception:
                self.disp.setText("Error"); self.expr = ""
        else:
            self.expr += t; self.disp.setText(self.expr)

# =====================================================================
#  3. WINTRA GAMES (Snake + Minesweeper)
# =====================================================================
class SnakeWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus); self.setMinimumSize(440, 350)
        self.best = 0; self.reset()
        self.timer = QTimer(self); self.timer.timeout.connect(self.step); self.timer.start(110)

    def reset(self):
        self.snake = [(10, 8), (9, 8), (8, 8)]
        self.dir = (1, 0); self.food = (16, 8); self.score = 0; self.alive = True; self.update()

    def keyPressEvent(self, e):
        k = e.key()
        if k in (Qt.Key.Key_Up, Qt.Key.Key_W) and self.dir != (0, 1): self.dir = (0, -1)
        elif k in (Qt.Key.Key_Down, Qt.Key.Key_S) and self.dir != (0, -1): self.dir = (0, 1)
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_A) and self.dir != (1, 0): self.dir = (-1, 0)
        elif k in (Qt.Key.Key_Right, Qt.Key.Key_D) and self.dir != (-1, 0): self.dir = (1, 0)
        elif k == Qt.Key.Key_Space and not self.alive: self.reset()

    def step(self):
        if not self.alive: return
        hx, hy = self.snake[0][0] + self.dir[0], self.snake[0][1] + self.dir[1]
        if not (0 <= hx < 24 and 0 <= hy < 18) or (hx, hy) in self.snake:
            self.alive = False; self.update(); return
        self.snake.insert(0, (hx, hy))
        if (hx, hy) == self.food:
            self.score += 10; self.best = max(self.best, self.score)
            self.food = (random.randint(0, 23), random.randint(0, 17))
        else:
            self.snake.pop()
        self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#080d18"))
        cell = 18; ox = (self.width() - 24 * cell) // 2; oy = 32
        p.setPen(QColor("#e2e8f0"))
        p.drawText(ox, 20, f"Score: {self.score}   |   Best: {self.best}   (Arrows / WASD, Space = restart)")
        p.fillRect(ox, oy, 24 * cell, 18 * cell, QColor("#0f172a"))
        p.setBrush(QColor("#ef4444")); p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(ox + self.food[0]*cell + 2, oy + self.food[1]*cell + 2, cell - 4, cell - 4, 5, 5)
        for i, (x, y) in enumerate(self.snake):
            p.setBrush(QColor("#34d399" if i == 0 else "#10b981"))
            p.drawRoundedRect(ox + x*cell + 1, oy + y*cell + 1, cell - 2, cell - 2, 4, 4)
        if not self.alive:
            p.setPen(QColor("#f87171")); p.setFont(QFont("Inter", 18, QFont.Weight.Bold))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "GAME OVER — Press Space")

class MinesWidget(QWidget):
    def __init__(self):
        super().__init__()
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.info = QLabel("Left click = reveal, Right click = flag")
        btn = QPushButton("New Game"); btn.setObjectName("Primary"); btn.clicked.connect(self.reset)
        top.addWidget(self.info); top.addStretch(); top.addWidget(btn); lay.addLayout(top)
        self.grid = QGridLayout(); self.grid.setSpacing(3); lay.addLayout(self.grid)
        self.btns = {}
        for r in range(9):
            for c in range(9):
                b = QPushButton(""); b.setFixedSize(36, 36)
                b.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                b.clicked.connect(lambda _, rr=r, cc=c: self.reveal(rr, cc))
                b.customContextMenuRequested.connect(lambda _, rr=r, cc=c: self.flag(rr, cc))
                self.grid.addWidget(b, r, c); self.btns[(r, c)] = b
        self.reset()

    def reset(self):
        self.mines = set(random.sample([(r, c) for r in range(9) for c in range(9)], 12))
        self.rev = set(); self.flags = set(); self.over = False
        self.info.setText("Find all safe tiles (12 mines)")
        for b in self.btns.values(): b.setText(""); b.setEnabled(True); b.setStyleSheet("")

    def adj(self, r, c):
        return sum((r+dr, c+dc) in self.mines for dr in (-1,0,1) for dc in (-1,0,1) if (dr or dc))

    def flag(self, r, c):
        if self.over or (r, c) in self.rev: return
        if (r, c) in self.flags: self.flags.remove((r, c)); self.btns[(r, c)].setText("")
        else: self.flags.add((r, c)); self.btns[(r, c)].setText("🚩")

    def reveal(self, r, c):
        if self.over or (r, c) in self.rev or (r, c) in self.flags: return
        self.rev.add((r, c)); b = self.btns[(r, c)]
        if (r, c) in self.mines:
            b.setText("💣"); b.setStyleSheet("background: #dc2626;"); self.over = True
            self.info.setText("BOOM! You hit a mine."); return
        n = self.adj(r, c)
        b.setText(str(n) if n else ""); b.setEnabled(False); b.setStyleSheet("background: #0f172a; color: #60a5fa;")
        if n == 0:
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    if 0 <= r+dr < 9 and 0 <= c+dc < 9: self.reveal(r+dr, c+dc)
        if len(self.rev) == 81 - len(self.mines):
            self.over = True; self.info.setText("🎉 You win!")

class GamesApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("games_title")); self.resize(520, 440); set_app_icon(self)
        tabs = QTabWidget()
        tabs.addTab(SnakeWidget(), "🐍 Snake")
        tabs.addTab(MinesWidget(), "💣 Minesweeper")
        self.setCentralWidget(tabs)

# =====================================================================
#  4. WINTRA CLOCK (Clock + Stopwatch + Timer)
# =====================================================================
class ClockApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("clock_title")); self.setFixedSize(420, 340); set_app_icon(self)
        tabs = QTabWidget(); self.setCentralWidget(tabs)

        t1 = QWidget(); l1 = QVBoxLayout(t1)
        self.lbl_t = QLabel("00:00:00"); self.lbl_t.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_t.setStyleSheet("font-size: 54px; font-weight: 800; color: #ffffff;")
        self.lbl_d = QLabel(""); self.lbl_d.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_d.setStyleSheet("font-size: 16px; color: #94a3b8;")
        l1.addStretch(); l1.addWidget(self.lbl_t); l1.addWidget(self.lbl_d); l1.addStretch()
        tabs.addTab(t1, "Clock")

        t2 = QWidget(); l2 = QVBoxLayout(t2)
        self.sw_ms = 0; self.sw_run = False
        self.lbl_sw = QLabel("00:00.0"); self.lbl_sw.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_sw.setStyleSheet("font-size: 48px; font-weight: 800; color: #34d399;")
        l2.addStretch(); l2.addWidget(self.lbl_sw)
        h2 = QHBoxLayout()
        self.b_sw = QPushButton("Start"); self.b_sw.setObjectName("Primary"); self.b_sw.clicked.connect(self.toggle_sw)
        b_rst = QPushButton("Reset"); b_rst.clicked.connect(self.reset_sw)
        h2.addWidget(self.b_sw); h2.addWidget(b_rst); l2.addLayout(h2); l2.addStretch()
        tabs.addTab(t2, "Stopwatch")

        t3 = QWidget(); l3 = QVBoxLayout(t3)
        self.tm_sec = 60; self.tm_run = False
        self.lbl_tm = QLabel("01:00"); self.lbl_tm.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_tm.setStyleSheet("font-size: 48px; font-weight: 800; color: #fbbf24;")
        l3.addStretch(); l3.addWidget(self.lbl_tm)
        h3 = QHBoxLayout()
        self.b_tm = QPushButton("Start"); self.b_tm.setObjectName("Primary"); self.b_tm.clicked.connect(self.toggle_tm)
        b_p = QPushButton("+1 min"); b_p.clicked.connect(lambda: self.add_tm(60))
        b_m = QPushButton("Reset"); b_m.clicked.connect(lambda: self.set_tm(60))
        h3.addWidget(self.b_tm); h3.addWidget(b_p); h3.addWidget(b_m); l3.addLayout(h3); l3.addStretch()
        tabs.addTab(t3, "Timer")

        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(100)
        self.sub = 0; self.tick()

    def toggle_sw(self): self.sw_run = not self.sw_run; self.b_sw.setText("Pause" if self.sw_run else "Start")
    def reset_sw(self): self.sw_run = False; self.sw_ms = 0; self.b_sw.setText("Start"); self.lbl_sw.setText("00:00.0")
    def toggle_tm(self): self.tm_run = not self.tm_run; self.b_tm.setText("Stop" if self.tm_run else "Start")
    def add_tm(self, s): self.tm_sec += s; self.lbl_tm.setText(f"{self.tm_sec//60:02d}:{self.tm_sec%60:02d}")
    def set_tm(self, s): self.tm_run = False; self.b_tm.setText("Start"); self.tm_sec = s; self.lbl_tm.setText(f"{s//60:02d}:{s%60:02d}")

    def tick(self):
        now = datetime.now()
        self.lbl_t.setText(now.strftime("%H:%M:%S"))
        self.lbl_d.setText(now.strftime("%A, %B %d, %Y"))
        if self.sw_run:
            self.sw_ms += 100
            s = self.sw_ms // 1000; d = (self.sw_ms % 1000) // 100
            self.lbl_sw.setText(f"{s//60:02d}:{s%60:02d}.{d}")
        self.sub = (self.sub + 1) % 10
        if self.sub == 0 and self.tm_run:
            if self.tm_sec > 0:
                self.tm_sec -= 1; self.lbl_tm.setText(f"{self.tm_sec//60:02d}:{self.tm_sec%60:02d}")
            else:
                self.tm_run = False; self.b_tm.setText("Start")
                QMessageBox.information(self, "Wintra Clock", "⏰ Timer finished!")

# =====================================================================
#  5. WINTRA PAINT
# =====================================================================
class PaintCanvas(QWidget):
    def __init__(self):
        super().__init__()
        self.img = QImage(820, 500, QImage.Format.Format_ARGB32)
        self.img.fill(Qt.GlobalColor.white)
        self.color = QColor("#3b82f6"); self.size = 6; self.last = None

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton: self.last = e.position().toPoint()

    def mouseMoveEvent(self, e):
        if e.buttons() & Qt.MouseButton.LeftButton and self.last:
            p = QPainter(self.img); p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setPen(QPen(self.color, self.size, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            cur = e.position().toPoint(); p.drawLine(self.last, cur); self.last = cur; self.update()

    def mouseReleaseEvent(self, _): self.last = None
    def paintEvent(self, _): p = QPainter(self); p.drawImage(0, 0, self.img)

class PaintApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("paint_title")); self.resize(860, 580); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w)
        bar = QHBoxLayout(); self.canvas = PaintCanvas()
        for col in ["#000000","#ef4444","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ffffff"]:
            b = QPushButton(); b.setFixedSize(26, 26)
            b.setStyleSheet(f"background:{col}; border-radius:13px; border:2px solid #475569;")
            b.clicked.connect(lambda _, c=col: setattr(self.canvas, "color", QColor(c)))
            bar.addWidget(b)
        b_pick = QPushButton("Color..."); b_pick.clicked.connect(self.pick_color); bar.addWidget(b_pick)
        sl = QSlider(Qt.Orientation.Horizontal); sl.setRange(2, 36); sl.setValue(6); sl.setFixedWidth(90)
        sl.valueChanged.connect(lambda v: setattr(self.canvas, "size", v)); bar.addWidget(sl)
        b_clr = QPushButton("Clear"); b_clr.setObjectName("Danger"); b_clr.clicked.connect(self.clear); bar.addWidget(b_clr)
        b_sav = QPushButton("Save PNG"); b_sav.setObjectName("Success"); b_sav.clicked.connect(self.save); bar.addWidget(b_sav)
        bar.addStretch(); lay.addLayout(bar); lay.addWidget(self.canvas)

    def pick_color(self):
        c = QColorDialog.getColor(self.canvas.color, self)
        if c.isValid(): self.canvas.color = c
    def clear(self): self.canvas.img.fill(Qt.GlobalColor.white); self.canvas.update()
    def save(self):
        os.makedirs(os.path.expanduser("~/Pictures"), exist_ok=True)
        path, _ = QFileDialog.getSaveFileName(self, "Save Image", os.path.expanduser("~/Pictures/drawing.png"), "PNG (*.png)")
        if path: self.canvas.img.save(path); QMessageBox.information(self, "Saved", f"Saved to:\n{path}")

# =====================================================================
#  6. WINTRA WEATHER (Live Open-Meteo)
# =====================================================================
class WeatherWorker(QThread):
    done = pyqtSignal(str)
    def __init__(self, city): super().__init__(); self.city = city
    def run(self):
        try:
            import requests
            g = requests.get(f"https://geocoding-api.open-meteo.com/v1/search?name={self.city}&count=1", timeout=6).json()
            if not g.get("results"): self.done.emit("City not found."); return
            r = g["results"][0]
            w = requests.get(f"https://api.open-meteo.com/v1/forecast?latitude={r['latitude']}&longitude={r['longitude']}&current=temperature_2m,wind_speed_10m,relative_humidity_2m", timeout=6).json()
            cur = w["current"]
            self.done.emit(f"{r['name']} ({r.get('country','')})\n\n🌡️  {cur['temperature_2m']} °C\n💨  Wind: {cur['wind_speed_10m']} km/h\n💧  Humidity: {cur['relative_humidity_2m']} %")
        except Exception as e:
            self.done.emit(f"Could not fetch live weather (check internet).\n{e}")

class WeatherApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("weather_title")); self.setFixedSize(400, 320); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w); lay.setContentsMargins(20, 20, 20, 20)
        row = QHBoxLayout()
        self.city = QLineEdit("New York")
        b = QPushButton("Search"); b.setObjectName("Primary"); b.clicked.connect(self.fetch)
        row.addWidget(self.city); row.addWidget(b); lay.addLayout(row)
        self.out = QLabel("Loading live weather..."); self.out.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.out.setStyleSheet("font-size: 18px; background: #131c31; border-radius: 14px; padding: 20px;")
        lay.addWidget(self.out); self.fetch()

    def fetch(self):
        self.out.setText("Loading..."); self.wk = WeatherWorker(self.city.text().strip() or "New York")
        self.wk.done.connect(self.out.setText); self.wk.start()

# =====================================================================
#  7. WINTRA SECURITY
# =====================================================================
class SecurityApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("sec_title")); self.setFixedSize(460, 360); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w); lay.setContentsMargins(20, 20, 20, 20); lay.setSpacing(12)
        hdr = QLabel("🛡️  Wintra Shield"); hdr.setStyleSheet("font-size: 22px; font-weight: 800; color: #34d399;"); lay.addWidget(hdr)
        self.status = QLabel(""); self.status.setStyleSheet("background: #131c31; padding: 14px; border-radius: 12px;"); lay.addWidget(self.status)
        self.bar = QProgressBar(); self.bar.setValue(100); lay.addWidget(self.bar)
        row = QHBoxLayout()
        b_fw = QPushButton("Enable Firewall (UFW)"); b_fw.setObjectName("Primary"); b_fw.clicked.connect(self.enable_fw)
        b_ref = QPushButton("Refresh"); b_ref.clicked.connect(self.refresh)
        row.addWidget(b_fw); row.addWidget(b_ref); lay.addLayout(row); lay.addStretch(); self.refresh()

    def enable_fw(self): subprocess.run(["sudo", "ufw", "--force", "enable"], capture_output=True); self.refresh()
    def refresh(self):
        fw = subprocess.run(["sudo", "ufw", "status"], capture_output=True, text=True).stdout.strip()
        fw_line = "Active" if "active" in fw.lower() and "inactive" not in fw.lower() else "Disabled (click Enable)"
        mem = subprocess.run(["free", "-h"], capture_output=True, text=True).stdout.splitlines()
        ram = mem[1].split()[2] + " / " + mem[1].split()[1] if len(mem) > 1 else "?"
        self.status.setText(f"UFW Firewall:   {fw_line}\nRAM Usage:      {ram}\nWindows .exe:   Isolated in ~/.wintraos-win11\nSystem:         wintraOS 3.0")

# =====================================================================
#  8. WINTRAVPN
# =====================================================================
class VpnApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("vpn_title")); self.setFixedSize(440, 340); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w); lay.setContentsMargins(20, 20, 20, 20); lay.setSpacing(12)
        h = QLabel("🌐  WintraVPN"); h.setStyleSheet("font-size: 22px; font-weight: 800; color: #38bdf8;"); lay.addWidget(h)
        self.info = QLabel("Status: Disconnected\nImport any WireGuard profile (.conf), e.g. free Proton VPN config.")
        self.info.setWordWrap(True); self.info.setStyleSheet("background: #131c31; padding: 14px; border-radius: 12px;"); lay.addWidget(self.info)
        self.conf_path = None
        b_imp = QPushButton("Import WireGuard Profile (.conf)"); b_imp.clicked.connect(self.load_conf); lay.addWidget(b_imp)
        row = QHBoxLayout()
        b_on = QPushButton("Connect"); b_on.setObjectName("Success"); b_on.clicked.connect(self.connect_vpn)
        b_off = QPushButton("Disconnect"); b_off.setObjectName("Danger"); b_off.clicked.connect(self.disconnect_vpn)
        b_ip = QPushButton("Check My IP"); b_ip.clicked.connect(self.check_ip)
        row.addWidget(b_on); row.addWidget(b_off); row.addWidget(b_ip); lay.addLayout(row); lay.addStretch()

    def load_conf(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select WireGuard .conf", os.path.expanduser("~"), "WireGuard (*.conf)")
        if p: self.conf_path = p; self.info.setText(f"Loaded profile:\n{os.path.basename(p)}")
    def connect_vpn(self):
        if not self.conf_path: QMessageBox.warning(self, "WintraVPN", "Please import a .conf file first."); return
        r = subprocess.run(["sudo", "wg-quick", "up", self.conf_path], capture_output=True, text=True)
        self.info.setText("✓ Connected to VPN!" if r.returncode == 0 else f"Error:\n{r.stderr[:200]}")
    def disconnect_vpn(self):
        if self.conf_path: subprocess.run(["sudo", "wg-quick", "down", self.conf_path], capture_output=True)
        self.info.setText("Disconnected.")
    def check_ip(self):
        try:
            import requests
            d = requests.get("https://ipapi.co/json/", timeout=5).json()
            self.info.setText(f"Public IP: {d.get('ip','?')}\nLocation: {d.get('city','?')}, {d.get('country_name','?')}")
        except Exception:
            self.info.setText("Could not check IP (check internet).")

# =====================================================================
#  9. WINTRA CALENDAR
# =====================================================================
class CalendarApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("cal_title")); self.resize(520, 440); set_app_icon(self)
        self.db_path = os.path.expanduser("~/.wintraos_calendar.json")
        self.notes = json.load(open(self.db_path)) if os.path.exists(self.db_path) else {}
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w)
        self.cal = QCalendarWidget(); self.cal.selectionChanged.connect(self.load_note); lay.addWidget(self.cal)
        self.txt = QTextEdit(); self.txt.setPlaceholderText("Notes for selected date..."); self.txt.setMaximumHeight(110); lay.addWidget(self.txt)
        b = QPushButton("Save Note"); b.setObjectName("Primary"); b.clicked.connect(self.save_note); lay.addWidget(b)
        self.load_note()

    def key(self): return self.cal.selectedDate().toString("yyyy-MM-dd")
    def load_note(self): self.txt.setPlainText(self.notes.get(self.key(), ""))
    def save_note(self):
        self.notes[self.key()] = self.txt.toPlainText()
        json.dump(self.notes, open(self.db_path, "w"), ensure_ascii=False, indent=2)
        QMessageBox.information(self, "Saved", f"Note saved for {self.key()}.")

# =====================================================================
#  10. WINTRA SCREENSHOT
# =====================================================================
class ScreenshotApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("snap_title")); self.setFixedSize(360, 260); set_app_icon(self)
        w = QWidget(); self.setCentralWidget(w); lay = QVBoxLayout(w); lay.setContentsMargins(20, 20, 20, 20); lay.setSpacing(10)
        h = QLabel("📸  Wintra Screenshot"); h.setStyleSheet("font-size: 20px; font-weight: 800;"); lay.addWidget(h)
        b1 = QPushButton("Full Screen (Instant)"); b1.setObjectName("Primary"); b1.clicked.connect(lambda: self.snap("-f"))
        b2 = QPushButton("Select Area"); b2.clicked.connect(lambda: self.snap("-r"))
        b3 = QPushButton("Full Screen (3s Delay)"); b3.clicked.connect(lambda: self.snap("-f -d 3000"))
        lay.addWidget(b1); lay.addWidget(b2); lay.addWidget(b3); lay.addStretch()

    def snap(self, flags):
        os.makedirs(os.path.expanduser("~/Pictures"), exist_ok=True)
        out = os.path.expanduser(f"~/Pictures/screenshot_{datetime.now().strftime('%H%M%S')}.png")
        self.hide()
        QTimer.singleShot(300, lambda: self._run(flags, out))

    def _run(self, flags, out):
        subprocess.run(["spectacle", "-b", "-n", "-o", out] + flags.split())
        self.show()
        QMessageBox.information(self, "Wintra Screenshot", f"Saved to:\n{out}")

def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(QSS)
    mode = sys.argv[1] if len(sys.argv) > 1 else "--setup"
    cls = {
        "--setup": SetupWizard, "--calc": CalcApp, "--games": GamesApp,
        "--clock": ClockApp, "--paint": PaintApp, "--weather": WeatherApp,
        "--security": SecurityApp, "--vpn": VpnApp, "--calendar": CalendarApp,
        "--screenshot": ScreenshotApp,
    }.get(mode, SetupWizard)
    win = cls(); win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
