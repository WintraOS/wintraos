# wintraOS 3.1 Shell
[[ $- != *i* ]] && return
PS1='\[\e[1;34m\]wintra\[\e[0m\]@\[\e[1;36m\]wintraOS\[\e[0m\]:\[\e[1;37m\]\w\[\e[0m\]\$ '
alias ls='ls --color=auto'
alias sysinfo='fastfetch'
if [ -z "$WINTRA_GREETED" ]; then
    export WINTRA_GREETED=1
    command -v fastfetch >/dev/null 2>&1 && fastfetch
fi
